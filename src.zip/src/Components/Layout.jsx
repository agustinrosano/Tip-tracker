// Layout.jsx actualizado con sidebar deslizable
import React, { useState } from "react";
import { Link, Outlet, useLocation } from "react-router-dom";
import { Dialog, Transition } from "@headlessui/react";
import { Fragment } from "react";

export default function Layout() {
  const { pathname } = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navLinks = [
    { to: "/dashboard", label: "Dashboard" },
    { to: "/analytics", label: "Análisis" },
  ];

  return (
    <div className="min-h-screen bg-rose-50">
      {/* Mobile Nav Button */}
      <div className="sm:hidden p-4 flex justify-between items-center">
        <button
          onClick={() => setSidebarOpen(true)}
          className="text-rose-700 text-2xl focus:outline-none"
        >
          ☰
        </button>
        <h1 className="text-lg font-semibold text-rose-700">Tip-Tracker</h1>
      </div>

      {/* Sidebar para desktop */}
      <aside className="hidden sm:flex sm:w-64 bg-rose-200 text-rose-800 shadow-lg p-4 flex-col gap-6 fixed inset-y-0 left-0">
        <h1 className="text-2xl font-bold text-rose-700">💼 Tip-Tracker</h1>
        <nav className="flex flex-col gap-3">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`p-2 rounded hover:bg-rose-300 ${pathname === link.to ? "bg-rose-300 font-semibold" : ""}`}
            >
              {link.label}
            </Link>
          ))}
        </nav>
        <div className="mt-auto text-xs text-rose-600 text-center">
          © 2025 bubbaRossi
        </div>
      </aside>

      {/* Sidebar deslizable para mobile */}
      <Transition.Root show={sidebarOpen} as={Fragment}>
        <Dialog as="div" className="relative z-50 sm:hidden" onClose={setSidebarOpen}>
          <Transition.Child
            as={Fragment}
            enter="transition-opacity ease-linear duration-300"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="transition-opacity ease-linear duration-200"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <div className="fixed inset-0 bg-black bg-opacity-25" />
          </Transition.Child>

          <div className="fixed inset-0 flex z-40">
            <Transition.Child
              as={Fragment}
              enter="transition ease-in-out duration-300 transform"
              enterFrom="-translate-x-full"
              enterTo="translate-x-0"
              leave="transition ease-in-out duration-300 transform"
              leaveFrom="translate-x-0"
              leaveTo="-translate-x-full"
            >
              <Dialog.Panel className="relative flex w-full max-w-xs flex-col bg-rose-100 shadow-xl p-4">
                <button
                  onClick={() => setSidebarOpen(false)}
                  className="text-right text-rose-600 font-bold text-xl"
                >
                  ✕
                </button>
                <h1 className="text-xl font-bold text-rose-700 mb-4">Menú</h1>
                <nav className="flex flex-col gap-3">
                  {navLinks.map((link) => (
                    <Link
                      key={link.to}
                      to={link.to}
                      onClick={() => setSidebarOpen(false)}
                      className={`p-2 rounded hover:bg-rose-200 ${pathname === link.to ? "bg-rose-300 font-semibold" : ""}`}
                    >
                      {link.label}
                    </Link>
                  ))}
                </nav>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </Dialog>
      </Transition.Root>

      {/* Main content */}
      <main className="sm:ml-64 sm:p-6">
        <Outlet />
      </main>
    </div>
  );
}
