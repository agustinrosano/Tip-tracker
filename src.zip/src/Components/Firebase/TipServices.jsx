import {
  collection,
  addDoc,
  getDocs,
  deleteDoc,
  updateDoc,
  doc,
  query,
  orderBy,
  Timestamp,
} from "firebase/firestore";
import { db } from "../firebase";
import { where } from "firebase/firestore";

export const fetchTipsFromFirestore = async () => {
  const user = JSON.parse(localStorage.getItem("user")); // o auth.currentUser
  const tipsRef = collection(db, `users/${user.uid}/tips`);
  const q = query(tipsRef, orderBy("date", "desc"));
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
};

export const addTipToFirestore = async ({ amount, comment, date }) => {
  const user = JSON.parse(localStorage.getItem("user"));
  const tipRef = collection(db, `users/${user.uid}/tips`);
  return await addDoc(tipRef, {
    amount,
    comment,
    date,
    createdAt: Timestamp.now(),
    userId: user.uid,
  });
};

export const updateTipInFirestore = async (id, { amount, comment, date }) => {
  return await updateDoc(doc(db, "tips", id), {
    amount,
    comment,
    date,
    createdAt: Timestamp.now(),
  });
};

export const deleteTipFromFirestore = async (id) => {
  return await deleteDoc(doc(db, "tips", id));
};
